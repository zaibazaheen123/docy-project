const viewer=document.getElementById("viewer");
  function code() {
    const iframeWindow=viewer.contentWindow;
    console.log(iframeWindow.document);
  }